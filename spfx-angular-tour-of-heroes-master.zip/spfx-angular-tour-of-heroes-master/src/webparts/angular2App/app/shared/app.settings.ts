export class AppSettings {
    public static SHAREPOINT_SITE_URL: string ="https://localhost:4321";
    // "http://localhost:8080/" ;
    //"https://devashok.sharepoint.com/spa/";
}