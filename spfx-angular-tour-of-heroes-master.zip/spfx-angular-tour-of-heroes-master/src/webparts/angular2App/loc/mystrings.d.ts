declare interface IAngular2AppWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Angular2AppWebPartStrings' {
  const strings: IAngular2AppWebPartStrings;
  export = strings;
}
